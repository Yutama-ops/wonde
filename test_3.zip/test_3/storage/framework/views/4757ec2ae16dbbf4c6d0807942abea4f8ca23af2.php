<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>

<h1>User Management Page</h1>

<h2>Here are all the users:</h2>

<?php if($users->isEmpty()): ?>
    <li>None</li>
<?php else: ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($user->name); ?> - <?php echo e($user->email); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<br>
<h2>Add a New User</h2>
<form method="POST" action="users">



<p>
<input type="text" name="name" placeholder="Name" required>
</p>

<p>
<input type="email" name="email" placeholder="Email Address" required>
</p>

<p>
<input type="password" name="password" placeholder="Password" required>
</p>

<p>
    <button type="submit">Add User</button>
</p>

</form>

</body>

</html>
<?php /**PATH /Users/yutamabudiman/Developer/React/wonde/bitbucket/coding/resources/views/users/index.blade.php ENDPATH**/ ?>