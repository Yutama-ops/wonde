This simple application is built in Laravel.

Clone the repo to your local machine.

Run 'composer install' to set the dependencies.

Create your local environment file: 'cp .env.example .env'

Generate your application key: 'php artisan key:generate'

Create a local database: 'touch database/database.sqlite'

Run migrations to seed the DB: 'php artisan migrate'

Run 'php artisan serve' to run the application.

uncomment foreach loop in the index.blade.php file to display the users from the database

add if statement to check if the users array is empty and display a message if it is

@if($users->isEmpty())
    <li>None</li>
@else
    @foreach ($users as $user)
        <li>{{ $user->name }} - {{$user->email}}</li>
@endforeach
@endif

change method from get to post in the web.php file to add new users to the database
Route::post('users', [UsersController::class, 'store']);

and remove forward slash from the form method to cleanup the code

<form method="POST" action="users"/>
